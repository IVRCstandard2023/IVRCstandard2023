tic
now = toc;

while now < 3
    sprintf("%f",now)
    now = toc;
end
^